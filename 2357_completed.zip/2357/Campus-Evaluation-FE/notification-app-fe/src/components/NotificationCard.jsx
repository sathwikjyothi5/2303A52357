import { Box, Chip, Paper, Typography } from "@mui/material";

const typeColors = {
  Placement: "primary",
  Result: "success",
  Event: "warning",
};

export function NotificationCard({ notification }) {
  const { type, title, message, read, timestamp } = notification;

  return (
    <Paper
      variant="outlined"
      sx={{
        p: 2,
        opacity: read ? 0.7 : 1,
        borderLeft: read ? undefined : "4px solid",
        borderLeftColor: read ? undefined : "primary.main",
        backgroundColor: read ? "background.paper" : "action.hover",
      }}
    >
      <Box display="flex" justifyContent="space-between" alignItems="flex-start" mb={0.5}>
        <Typography variant="subtitle1" fontWeight={read ? 400 : 700}>
          {title}
        </Typography>
        <Chip
          label={type}
          size="small"
          color={typeColors[type] ?? "default"}
          sx={{ ml: 1, flexShrink: 0 }}
        />
      </Box>
      <Typography variant="body2" color="text.secondary" mb={1}>
        {message}
      </Typography>
      <Typography variant="caption" color="text.disabled">
        {new Date(timestamp).toLocaleString()}
      </Typography>
    </Paper>
  );
}
