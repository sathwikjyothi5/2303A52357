const MOCK_NOTIFICATIONS = [
  { id: 1, type: "Placement", title: "Campus Drive: TCS", message: "TCS is visiting campus on July 5th. Register by June 30.", read: false, timestamp: "2025-06-17T09:00:00Z" },
  { id: 2, type: "Result", title: "Exam Results Published", message: "Your semester results are now available on the portal.", read: false, timestamp: "2025-06-16T14:30:00Z" },
  { id: 3, type: "Event", title: "Tech Fest 2025", message: "Annual tech fest registrations are open. Last date: June 25.", read: true, timestamp: "2025-06-15T10:00:00Z" },
  { id: 4, type: "Placement", title: "Infosys Walk-in Drive", message: "Infosys is conducting a walk-in drive for 2025 batch.", read: true, timestamp: "2025-06-14T08:00:00Z" },
  { id: 5, type: "Event", title: "Hackathon Registration Open", message: "Register for the 24-hour hackathon happening next week.", read: false, timestamp: "2025-06-13T12:00:00Z" },
  { id: 6, type: "Result", title: "Internal Assessment Marks", message: "IA marks for all subjects have been uploaded.", read: true, timestamp: "2025-06-12T11:00:00Z" },
  { id: 7, type: "Placement", title: "Wipro Off-Campus Drive", message: "Wipro off-campus drive for CSE & IT students. Apply now.", read: false, timestamp: "2025-06-11T09:30:00Z" },
  { id: 8, type: "Event", title: "Guest Lecture: AI in Industry", message: "A guest lecture on AI applications is scheduled for June 22.", read: true, timestamp: "2025-06-10T15:00:00Z" },
];

const PAGE_SIZE = 5;

export async function fetchNotifications({ filter = "All", page = 1 } = {}) {
  await new Promise((res) => setTimeout(res, 400));

  const filtered =
    filter === "All"
      ? MOCK_NOTIFICATIONS
      : MOCK_NOTIFICATIONS.filter((n) => n.type === filter);

  const total = filtered.length;
  const totalPages = Math.ceil(total / PAGE_SIZE);
  const start = (page - 1) * PAGE_SIZE;
  const notifications = filtered.slice(start, start + PAGE_SIZE);

  return { notifications, total, totalPages };
}
