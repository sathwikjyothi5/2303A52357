## Logging Middleware
